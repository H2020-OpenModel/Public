"""
This script extracts the stresses and strains extrapolated to the nodes.
"""
from glob import glob
import json
import numpy as np
from abaqus import *
from abaqusConstants import *

session.Viewport(name='Viewport: 1', origin=(0.0, 0.0), width=380, height=230)
session.viewports['Viewport: 1'].makeCurrent()
session.viewports['Viewport: 1'].maximize()

from caeModules import *
from driverUtils import executeOnCaeStartup

executeOnCaeStartup()
session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
    referenceRepresentation=ON)
#---------------------------------------------------------------------
part = 'ONESECTION-1-MESH-1-1'
conSurf = 'CONNECTORSURF'
NodeSet = 'ALU'
#---------------------------------------------------------------------
def unknownLengthSummer(X,Y):
    #this function sums the Y axis, based on repetative values of the X axis.
    out = []
    uni = []
    CurrentV = 0.0
    CurrentX = 0.0
    j = 1
    for i in range(1,len(Y)):
        if X[i] == X[i-1]:
            CurrentV += Y[i]
            CurrentX = X[i]
            j += 1
        else:
            out.append(CurrentV/j)
            uni.append(CurrentX)
            CurrentV = Y[i]
            CurrentX = X[i]
            j = 1
        if i == (len(Y)-1):
            out.append(CurrentV/j)
            uni.append(CurrentX)
    return out


def read_avg_field_node(odb, vari, comp, part, node):
    rawData = session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=((vari, 
    INTEGRATION_POINT, ((COMPONENT, comp), )), ), nodeLabels=((
    part, (node, )), ))
    rawData =np.array(rawData[0])
    Y = rawData[:,1]
    X = rawData[:,0]
    Data = unknownLengthSummer(X,Y)
    delName = vari +  ':' + comp + ' (Avg: 75%) PI: ' + part + ' N: ' + node
    del session.xyDataObjects[delName]
    return Data


def read_field_node(odb, vari, comp, part, node):
    rawData = session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=((vari, 
    NODAL, ((COMPONENT, comp), )), ), nodeLabels=((part, (
    node, )), ))
    rawData =np.array(rawData[0])
    Data = rawData[:,1]
    delName = vari +  ':' + comp + ' PI: ' + part + ' N: ' + node
    del session.xyDataObjects[delName]
    return Data


def read_time_node(odb, vari, comp, part, node):
    rawData = session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=((vari, 
    NODAL, ((COMPONENT, comp), )), ), nodeLabels=((part, (
    node, )), ))
    rawData =np.array(rawData[0])
    Data = rawData[:,0]
    delName = vari +  ':' + comp + ' PI: ' + part + ' N: ' + node
    del session.xyDataObjects[delName]
    return Data


def FaceNodes(FACE, connectivity):
    if 'FACE1' in str(FACE):
    #Face 1: 1-2-3-4
        a = 0
        b = 1
        c = 2
        d = 3
    elif 'FACE2' in str(FACE):
    #Face 2: 5-8-7-6
        a = 4
        b = 7
        c = 6
        d = 5
    elif 'FACE3' in str(FACE):
    #Face 3: 1-5-6-2
        a = 0
        b = 4
        c = 5
        d = 1        
    elif 'FACE4' in str(FACE):
    #Face 4: 2-6-7-3
        a = 1
        b = 5
        c = 6
        d = 2
    elif 'FACE5' in str(FACE):
    #Face 5: 3-7-8-4
        a = 2
        b = 6
        c = 7
        d = 3
    elif 'FACE6' in str(FACE):
    #Face 6: 4-8-5-1
        a = 3
        b = 7
        c = 4
        d = 0
    else:
        print('Something is wrong!!!')
    Fnodes = [connectivity[a],connectivity[b],connectivity[c],connectivity[d]]
    return Fnodes


def process_odb(filename):
    odb = session.openOdb(name=filename)
    session.viewports['Viewport: 1'].setValues(displayedObject=odb)
    allSteps = session.odbData[filename].steps.keys()
    allFrames = session.odbData[filename].steps[allSteps[0]].frames.keys()
    allNodes = {}

    for node in odb.rootAssembly.instances[part].nodeSets[NodeSet].nodes:
        allNodes[str(node.label)] = node.coordinates

    surface = odb.rootAssembly.instances[part].surfaces[conSurf]
    allconnectivity = {}
    elementList = []
    ValueVec = []
    FaceList = {}
    j = 0
    session.odbData[filename].setValues(activeFrames=((allSteps[0], (len(allFrames)-1, )), ))
    vari = 'S'
    comp = 'Pressure'
    dataObjectFormat = vari + ':' + comp + ' PI: ' + part + ' E: {}' + ' IP: 1'

    for element in surface.elements:
        allconnectivity[str(element.label)] = element.connectivity
        elementList.append(element.label)
        FaceList[str(element.label)] = str(surface.faces[j])
        session.xyDataListFromField(
            odb=odb,
            outputPosition=INTEGRATION_POINT,
            variable=((vari, INTEGRATION_POINT, ((INVARIANT, comp), )),),
            elementLabels=((part, (element.label, )), )
        )
        name = dataObjectFormat.format(element.label)
        dataObject = session.xyDataObjects[name]        
        P = np.array(dataObject)
        Data = P[:,1:P.shape[1]]
        del session.xyDataObjects[name]
        ValueVec.append(Data[len(Data)-1])
        j += 1
    
    critElem = str(elementList[np.argmin(ValueVec)])
    ref = np.array(allconnectivity[critElem])
    neighbor1 = {}
    neighbor2 = {}
    neighbornodes = []

    for element in allconnectivity:
        if critElem in element:
            continue
        check = np.array(allconnectivity[element])
        if len(np.setdiff1d(check,ref)) < len(ref)-2:
            neighbor2[element] = np.setdiff1d(check,ref).tolist()
            neighbornodes.append(np.setdiff1d(check,ref).tolist())
        elif len(np.setdiff1d(check,ref)) < len(ref):
            neighbor1[element] = np.setdiff1d(check,ref).tolist()

    for element in neighbor1:
        neighbor1[element] = np.setdiff1d(neighbor1[element],neighbornodes).tolist()
    
    print(neighbor2)
    print(neighbor1)

    # creating the array to hold the times
    times = []

    nodes = {}
    FaceCE = FaceNodes(FaceList[critElem],ref)
    session.odbData[filename].setValues(activeFrames=((allSteps[0], ('0:-1', )), ))
    for val in ref:
        coordinates = allNodes[str(val)]
        nodes[val] = {}
        t = np.array(read_time_node(odb, 'U', 'U1', part, str(val)))
        if times == []:
            times = t.tolist()
        else:
            if times != t.tolist():
                print("warning the list of times id different for val:",val)
        #nodes[val]['Time'] = t.tolist()
        x = np.array(read_field_node(odb, 'U', 'U1', part, str(val)))
        x += coordinates[0]
        nodes[val]['X'] = x.tolist()
        y = np.array(read_field_node(odb, 'U', 'U2', part, str(val)))
        y += coordinates[1]
        nodes[val]['Y'] = y.tolist()
        z = np.array(read_field_node(odb, 'U', 'U3', part, str(val)))
        z += coordinates[2]
        nodes[val]['Z'] = z.tolist()
        nodes[val]['LE11'] = read_avg_field_node(odb, 'LE', 'LE11', part, str(val))
        nodes[val]['LE22'] = read_avg_field_node(odb, 'LE', 'LE22', part, str(val))
        nodes[val]['LE33'] = read_avg_field_node(odb, 'LE', 'LE33', part, str(val))
        nodes[val]['LE12'] = read_avg_field_node(odb, 'LE', 'LE12', part, str(val))
        nodes[val]['LE23'] = read_avg_field_node(odb, 'LE', 'LE23', part, str(val))
        nodes[val]['LE31'] = read_avg_field_node(odb, 'LE', 'LE13', part, str(val))
        nodes[val]['S11'] = read_avg_field_node(odb, 'S', 'S11', part, str(val))
        nodes[val]['S22'] = read_avg_field_node(odb, 'S', 'S22', part, str(val))
        nodes[val]['S33'] = read_avg_field_node(odb, 'S', 'S33', part, str(val))
        nodes[val]['S12'] = read_avg_field_node(odb, 'S', 'S12', part, str(val))
        nodes[val]['S23'] = read_avg_field_node(odb, 'S', 'S23', part, str(val))
        nodes[val]['S31'] = read_avg_field_node(odb, 'S', 'S13', part, str(val))
    
    for j in range(len(FaceCE)):
        i = j-1
        k = j+1
        if j == 3:
            k = 0
        elif j == 0:
            i = 3
        u=np.zeros((3,len(nodes[FaceCE[j]]['X'])))
        v=np.zeros((3,len(nodes[FaceCE[j]]['X'])))
        n=np.zeros((3,len(nodes[FaceCE[j]]['X'])))
        u[0,:] = (np.array(nodes[FaceCE[i]]['X'])-np.array(nodes[FaceCE[j]]['X']))
        u[1,:] = (np.array(nodes[FaceCE[i]]['Y'])-np.array(nodes[FaceCE[j]]['Y']))
        u[2,:] = (np.array(nodes[FaceCE[i]]['Z'])-np.array(nodes[FaceCE[j]]['Z']))
        v[0,:] = (np.array(nodes[FaceCE[k]]['X'])-np.array(nodes[FaceCE[j]]['X']))
        v[1,:] = (np.array(nodes[FaceCE[k]]['Y'])-np.array(nodes[FaceCE[j]]['Y']))
        v[2,:] = (np.array(nodes[FaceCE[k]]['Z'])-np.array(nodes[FaceCE[j]]['Z']))
        for z in range(len(nodes[FaceCE[j]]['X'])):
            n[:,z] = np.cross(u[:,z],v[:,z])/np.linalg.norm(np.cross(u[:,z],v[:,z]))
        add = np.array(nodes[FaceCE[j]]['S11'])*n[0,:]+np.array(nodes[FaceCE[j]]['S12'])*n[1,:]+np.array(nodes[FaceCE[j]]['S31'])*n[2,:]
        nodes[FaceCE[j]]['T1'] =add.tolist()
        add = np.array(nodes[FaceCE[j]]['S12'])*n[0,:]+np.array(nodes[FaceCE[j]]['S22'])*n[1,:]+np.array(nodes[FaceCE[j]]['S23'])*n[2,:]
        nodes[FaceCE[j]]['T2'] =add.tolist()
        add = np.array(nodes[FaceCE[j]]['S31'])*n[0,:]+np.array(nodes[FaceCE[j]]['S23'])*n[1,:]+np.array(nodes[FaceCE[j]]['S33'])*n[2,:]
        nodes[FaceCE[j]]['T3'] =add.tolist()
    for element in neighbor2:        
        check = np.array(neighbor2[element])
        for val in check:
            coordinates = allNodes[str(val)]
            nodes[val] = {}
            t = np.array(read_time_node(odb, 'U', 'U1', part, str(val)))
            if times != t.tolist():
                print("warning the list of times id different for val:",val)
            #nodes[val]['Time'] = t.tolist()
            x = np.array(read_field_node(odb, 'U', 'U1', part, str(val)))
            x += coordinates[0]
            nodes[val]['X'] = x.tolist()
            y = np.array(read_field_node(odb, 'U', 'U2', part, str(val)))
            y += coordinates[1]
            nodes[val]['Y'] = y.tolist()
            z = np.array(read_field_node(odb, 'U', 'U3', part, str(val)))
            z += coordinates[2]
            nodes[val]['Z'] = z.tolist()
            nodes[val]['LE11'] = read_avg_field_node(odb, 'LE', 'LE11', part, str(val))
            nodes[val]['LE22'] = read_avg_field_node(odb, 'LE', 'LE22', part, str(val))
            nodes[val]['LE33'] = read_avg_field_node(odb, 'LE', 'LE33', part, str(val))
            nodes[val]['LE12'] = read_avg_field_node(odb, 'LE', 'LE12', part, str(val))
            nodes[val]['LE23'] = read_avg_field_node(odb, 'LE', 'LE23', part, str(val))
            nodes[val]['LE31'] = read_avg_field_node(odb, 'LE', 'LE13', part, str(val))
            nodes[val]['S11'] = read_avg_field_node(odb, 'S', 'S11', part, str(val))
            nodes[val]['S22'] = read_avg_field_node(odb, 'S', 'S22', part, str(val))
            nodes[val]['S33'] = read_avg_field_node(odb, 'S', 'S33', part, str(val))
            nodes[val]['S12'] = read_avg_field_node(odb, 'S', 'S12', part, str(val))
            nodes[val]['S23'] = read_avg_field_node(odb, 'S', 'S23', part, str(val))
            nodes[val]['S31'] = read_avg_field_node(odb, 'S', 'S13', part, str(val))
        FaceE = FaceNodes(FaceList[element],np.array(allconnectivity[element]))
        FaceEuni = np.arange(4)[np.isin(FaceE, check)]
        for Z in range(len(FaceEuni)):
            j = FaceEuni[Z]
            print(FaceE[j])
            i = j-1
            k = j+1
            if j == 3:
                k = 0
            elif j == 0:
                i = 3
            u=np.zeros((3,len(nodes[FaceE[j]]['X'])))
            v=np.zeros((3,len(nodes[FaceE[j]]['X'])))
            n=np.zeros((3,len(nodes[FaceE[j]]['X'])))
            u[0,:] = (np.array(nodes[FaceE[i]]['X'])-np.array(nodes[FaceE[j]]['X']))
            u[1,:] = (np.array(nodes[FaceE[i]]['Y'])-np.array(nodes[FaceE[j]]['Y']))
            u[2,:] = (np.array(nodes[FaceE[i]]['Z'])-np.array(nodes[FaceE[j]]['Z']))
            v[0,:] = (np.array(nodes[FaceE[k]]['X'])-np.array(nodes[FaceE[j]]['X']))
            v[1,:] = (np.array(nodes[FaceE[k]]['Y'])-np.array(nodes[FaceE[j]]['Y']))
            v[2,:] = (np.array(nodes[FaceE[k]]['Z'])-np.array(nodes[FaceE[j]]['Z']))
            for z in range(len(nodes[FaceE[j]]['X'])):
                n[:,z] = np.cross(u[:,z],v[:,z])/np.linalg.norm(np.cross(u[:,z],v[:,z]))
            add = np.array(nodes[FaceCE[j]]['S11'])*n[0,:]+np.array(nodes[FaceE[j]]['S12'])*n[1,:]+np.array(nodes[FaceE[j]]['S31'])*n[2,:]
            nodes[FaceE[j]]['T1'] =add.tolist()
            add = np.array(nodes[FaceCE[j]]['S12'])*n[0,:]+np.array(nodes[FaceE[j]]['S22'])*n[1,:]+np.array(nodes[FaceE[j]]['S23'])*n[2,:]
            nodes[FaceE[j]]['T2'] =add.tolist()
            add = np.array(nodes[FaceCE[j]]['S31'])*n[0,:]+np.array(nodes[FaceE[j]]['S23'])*n[1,:]+np.array(nodes[FaceE[j]]['S33'])*n[2,:]
            nodes[FaceE[j]]['T3'] =add.tolist()
    for element in neighbor1:        
        check = np.array(neighbor1[element])
        for val in check:
            coordinates = allNodes[str(val)]
            nodes[val] = {}
            t = np.array(read_time_node(odb, 'U', 'U1', part, str(val)))
            if times != t.tolist():
                print("warning the list of times id different for val:",val)
            #nodes[val]['Time'] = t.tolist()
            x = np.array(read_field_node(odb, 'U', 'U1', part, str(val)))
            x += coordinates[0]
            nodes[val]['X'] = x.tolist()
            y = np.array(read_field_node(odb, 'U', 'U2', part, str(val)))
            y += coordinates[1]
            nodes[val]['Y'] = y.tolist()
            z = np.array(read_field_node(odb, 'U', 'U3', part, str(val)))
            z += coordinates[2]
            nodes[val]['Z'] = z.tolist()
            nodes[val]['LE11'] = read_avg_field_node(odb, 'LE', 'LE11', part, str(val))
            nodes[val]['LE22'] = read_avg_field_node(odb, 'LE', 'LE22', part, str(val))
            nodes[val]['LE33'] = read_avg_field_node(odb, 'LE', 'LE33', part, str(val))
            nodes[val]['LE12'] = read_avg_field_node(odb, 'LE', 'LE12', part, str(val))
            nodes[val]['LE23'] = read_avg_field_node(odb, 'LE', 'LE23', part, str(val))
            nodes[val]['LE31'] = read_avg_field_node(odb, 'LE', 'LE13', part, str(val))
            nodes[val]['S11'] = read_avg_field_node(odb, 'S', 'S11', part, str(val))
            nodes[val]['S22'] = read_avg_field_node(odb, 'S', 'S22', part, str(val))
            nodes[val]['S33'] = read_avg_field_node(odb, 'S', 'S33', part, str(val))
            nodes[val]['S12'] = read_avg_field_node(odb, 'S', 'S12', part, str(val))
            nodes[val]['S23'] = read_avg_field_node(odb, 'S', 'S23', part, str(val))
            nodes[val]['S31'] = read_avg_field_node(odb, 'S', 'S13', part, str(val))
        FaceE = FaceNodes(FaceList[element],np.array(allconnectivity[element]))
        FaceEuni = np.arange(4)[np.isin(FaceE, check)]
        for Z in range(len(FaceEuni)):
            j = FaceEuni[Z]
            print(FaceE[j])
        i = j-1
        k = j+1
        if j == 3:
            k = 0
        elif j == 0:
            i = 3
        u=np.zeros((3,len(nodes[FaceE[j]]['X'])))
        v=np.zeros((3,len(nodes[FaceE[j]]['X'])))
        n=np.zeros((3,len(nodes[FaceE[j]]['X'])))
        u[0,:] = (np.array(nodes[FaceE[i]]['X'])-np.array(nodes[FaceE[j]]['X']))
        u[1,:] = (np.array(nodes[FaceE[i]]['Y'])-np.array(nodes[FaceE[j]]['Y']))
        u[2,:] = (np.array(nodes[FaceE[i]]['Z'])-np.array(nodes[FaceE[j]]['Z']))
        v[0,:] = (np.array(nodes[FaceE[k]]['X'])-np.array(nodes[FaceE[j]]['X']))
        v[1,:] = (np.array(nodes[FaceE[k]]['Y'])-np.array(nodes[FaceE[j]]['Y']))
        v[2,:] = (np.array(nodes[FaceE[k]]['Z'])-np.array(nodes[FaceE[j]]['Z']))
        for z in range(len(nodes[FaceE[j]]['X'])):
            n[:,z] = np.cross(u[:,z],v[:,z])/np.linalg.norm(np.cross(u[:,z],v[:,z]))
        add = np.array(nodes[FaceCE[j]]['S11'])*n[0,:]+np.array(nodes[FaceE[j]]['S12'])*n[1,:]+np.array(nodes[FaceE[j]]['S31'])*n[2,:]
        nodes[FaceE[j]]['T1'] =add.tolist()
        add = np.array(nodes[FaceCE[j]]['S12'])*n[0,:]+np.array(nodes[FaceE[j]]['S22'])*n[1,:]+np.array(nodes[FaceE[j]]['S23'])*n[2,:]
        nodes[FaceE[j]]['T2'] =add.tolist()
        add = np.array(nodes[FaceCE[j]]['S31'])*n[0,:]+np.array(nodes[FaceE[j]]['S23'])*n[1,:]+np.array(nodes[FaceE[j]]['S33'])*n[2,:]
        nodes[FaceE[j]]['T3'] =add.tolist()
    
    # create the dictionnary
    dict0 = dict(nodes=nodes)
    dict0["times"] = times
    with open('CementOutput.json', 'w') as fil:
        json.dump(dict0, fil, indent=2)

files = glob('*.odb')
if files:
    process_odb(files[0])
